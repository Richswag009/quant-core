<?php

namespace App\Jobs;

use App\Enums\BatchStatus;
use App\Enums\BatchStatusItem;
use App\Services\Batch\FakePostingService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Testing\Fakes\Fake;
use App\Models\Batch;
use App\Services\AuditTrails\AuditTrailService;

class PostBatchJob implements ShouldQueue
{
    use Queueable;


    /**
     * Create a new job instance.
     */
    public function __construct(
        public Batch $batch,
        public string $tenantId,
        public int $userId
    ) {}
    /**
     * Execute the job.
     */
    public function handle(FakePostingService $fakePostingService, AuditTrailService $auditTrail): void
    {

        $items = $this->batch->items()
            ->where('tenant_id', $this->tenantId)
            ->whereIn('status', [BatchStatusItem::VALID->value, BatchStatusItem::FAILED->value])
            ->get();

        foreach ($items as $item) {

            try {
                $fakePostingService->postBatch($item);
                $item->status = BatchStatusItem::POSTED->value;
                $item->posted_at = now();
                $item->save();
            } catch (\Throwable $th) {
                $item->status = BatchStatusItem::FAILED->value;
                $item->posting_error = $th->getMessage();
                $item->save();
            }
        }

        // update batch status after all items are processed
        $hasFailures = $this->batch->items()
            ->where('status', BatchStatusItem::FAILED->value)
            ->exists();

        $this->batch->update([
            'status'    => $hasFailures ? BatchStatus::PARTIALLY_POSTED->value : BatchStatus::POSTED->value,
            'posted_at' => now(),
        ]);

        $postedCount = $this->batch->items()->where('status', BatchStatusItem::POSTED->value)->count();
        $failedCount = $this->batch->items()->where('status', BatchStatusItem::FAILED->value)->count();

        // PostBatchJob
        $auditTrail->log(
            $this->batch,
            'POSTED',
            [
                'posted' => $postedCount,
                'failed' => $failedCount,
            ],
            $this->userId
        );
    }
}
